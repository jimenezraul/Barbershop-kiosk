setTimeout(function() {
  $('#mydiv').fadeOut('fast');
}, 2000); // <-- time in milliseconds