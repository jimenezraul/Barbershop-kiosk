function showFunction() {
        var x = document.getElementById("hideDiv");
        if (x.style.display === "none") {
          x.style.display = "block";
        } 
      }

function closeFunction() {
var x = document.getElementById("hideDiv");
if (x.style.display === "block") {
        x.style.display = "none";
} 
}