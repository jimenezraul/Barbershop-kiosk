setTimeout(function() {
    $('#alert-mobile').fadeOut('fast');
  }, 2000); // <-- time in milliseconds